#!/bin/sh

set -e

echo "start the app"
exec "$@"
